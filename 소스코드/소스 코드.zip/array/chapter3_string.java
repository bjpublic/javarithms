package array;

public class chapter3_string {
	public static void main(String[] args) {
		String str1 = "ar";
		String str2 = "a";
		String str3 = new String("a");

		System.out.println(str1 == str2);
		System.out.println(str1 == str3);
	}
}
