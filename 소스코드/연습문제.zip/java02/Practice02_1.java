package practice.java02;

import java.util.Scanner;

/**
 * 5개의 양수를 입력받은 배열의 모든 요소의 합을 구하는 메서드를 작성해 보세요.
 */
public class Practice02_1 {
    public static void main(String[] args) {
        int[] arr = new int[5];
        int sum = 0;

        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            System.out.print("양수를 입력하세요. ");
            arr[i] = scanner.nextInt();
        }

        for (int data : arr) {
            sum += data;
        }

        System.out.println("배열의 모든 요소의 합: " + sum);
    }
}
