package practice.java02;

/**
 * 배열의 최댓값과 최솟값을 구하는 메서드를 작성해 보세요.
 */
public class Practice02_2 {
    public static void main(String[] args) {
        int[] arr = {10, 11, 2, 5, 3, 3, 24, 15, 6, 9};
        int max = arr[0];
        int min = arr[0];

        for (int data : arr) {
            if (data < min) {
                min = data;
            }

            if (data > max) {
                max = data;
            }
        }

        System.out.println("최솟값: " + min);
        System.out.println("최댓값: " + max);
    }
}
