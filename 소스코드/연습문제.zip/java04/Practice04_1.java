package practice.java04;

import java.util.Scanner;

/**
 * 입력받은 두 양수를 x, n 변수에 할당하고 x의 n제곱을 재귀적으로 구현해 보세요.
 */
public class Practice04_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("x의 값을 입력하세요. ");
        int x = scanner.nextInt();

        System.out.print("n의 값을 입력하세요. ");
        int n = scanner.nextInt();

        System.out.println(String.format("%d의 %d 제곱은: %s 입니다.", x, n, pow(x, n)));
    }

    private static int pow(int x, int n) {
        if (n == 1) {
            return x;
        }

        return x * pow(x, n - 1);
    }
}
