package practice.java10;

import java.util.Arrays;

/**
 * {학생 이름/학생 번호}로 정리된 학생부가 있습니다.
 * 이 학생부를 두 가지 방법으로 셸 정렬을 이용하여 오름차순으로 정렬해 보세요.
 * 조건) 학생 이름 기준으로 오름차순
 *       학생 번호 기준으로 오름차순
 */
public class Practice10_01 {
    public static void main(String[] args) {
        String[] filnames = {
                "D/22" ,"A/14", "T/03", "F/09", "S/15",
                "B/10", "R/01", "J/05", "H/23", "Y/08"
        };

        sort(filnames, "name");
        System.out.println(String.format("학생 이름(오름차순): %s", Arrays.toString(filnames)));

        sort(filnames, "number");
        System.out.println(String.format("학생 번호(오름차순): %s", Arrays.toString(filnames)));
    }

    private static void sort(String[] arr, String type) {
        int length = arr.length;

        for (int gap = length / 2; gap > 0; gap /= 2) {
            for (int startIndex = 0; startIndex < gap; startIndex++) {
                insertionSortByGap(arr, gap, startIndex, type);
            }
        }
    }

    private static void insertionSortByGap(String[] arr, int gap, int startIndex, String type) {
        int valueIndex = "name".equals(type) ? 0 : 1;

        for (int i = startIndex + gap; i < arr.length; i += gap) {
            String target = arr[i];

            int j;
            for (j = i - gap; j >= 0; j -= gap) {
                if (compare(arr[j], target, valueIndex)) {
                    break;
                }
                arr[j + gap] = arr[j];
            }
            arr[j + gap] = target;
        }
    }

    private static boolean compare(String compareTarget, String originTarget, int valueIndex) {
        if (valueIndex == 0) {
            int compareA = compareTarget.split("/")[valueIndex].hashCode();
            int compareB = originTarget.split("/")[valueIndex].hashCode();

            if (compareA < compareB) {
                return true;
            }
        } else {
            int compareA = Integer.valueOf(compareTarget.split("/")[valueIndex]);
            int compareB = Integer.valueOf(originTarget.split("/")[valueIndex]);
            if (compareA < compareB) {
                return true;
            }
        }
        return false;
    }
}
