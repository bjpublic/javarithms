package practice.java13;

import java.util.ArrayList;
import java.util.List;

/**
 * 아래 조건을 만족하는 디렉토리 구조를 구현해 보세요.
 *
 * 조건)
 *   폴더 생성 및 삭제, 검색을 할 수 있습니다.
 *   폴더는 트리의 노드 형태로 구성되며 부모 또는 자식 노드(폴더)를 가질 수 있습니다.
 *   전체 폴더 경로 출력과 폴더의 생성 및 삭제, 단일 폴더 경로 출력을 할 수 있습니다.
 *
 * 예제)
 *  '꽃/장미'
 *  '꽃/민들레'
 *
 *  위와 같이 4개의 폴더가 생성되어 있으며 각각의 폴더는 하위 폴더를 가질 수 있습니다.
 *  '꽃' 폴더를 조회하면 '꽃', '꽃/장미'와 같이 하위에 존재하는 모든 폴더를 화면에 출력합니다.
 *  상위 폴더가 존재하는 '민들레' 폴더를 조회하면 '꽃/민들레' 경로를 화면에 출력합니다.
 *  존재하지 않는 폴더는 "'{검색한 폴더명}'이 존재하지 않습니다."라는 문구를 제공합니다.
 */
public class Practice13_02 {
    private static class Directory {
        String name;
        List<Directory> childList;
        Directory parent;

        public Directory(String name) {
            this.name = name;
            this.childList = new ArrayList<>();
            this.parent = null;
        }

        private void addChild(Directory child) {
            this.childList.add(child);
            child.setParent(this);
        }

        private void setParent(Directory parent) {
            this.parent = parent;
        }

        public List<Directory> getChildList() {
            return this.childList;
        }

        public Directory getParent() {
            return this.parent;
        }

        public String getName() {
            return this.name;
        }

        public boolean hasChild() {
            return this.childList.size() > 0;
        }

        public boolean hasParent() {
            return this.parent != null;
        }

        public void delete() {
            this.parent = null;
            this.childList = null;
        }
    }

    public static void main(String[] args) {
        List<Directory> root =  new ArrayList<>();
        Directory flower = new Directory("꽃");
        Directory food = new Directory("음식");
        Directory animal = new Directory("동물");

        flower.addChild(new Directory("장미"));
        flower.addChild(new Directory("민들레"));

        Directory pizza = new Directory("피자");
        food.addChild(pizza);
        pizza.addChild(new Directory("가게 정보"));

        food.addChild(new Directory("치킨"));
        food.addChild(new Directory("햄버거"));

        Directory lion = new Directory("사자");
        Directory habitat = new Directory("서식지");
        habitat.addChild(new Directory("아프리카"));
        habitat.addChild(new Directory("아시아"));
        habitat.addChild(new Directory("유럽"));

        lion.addChild(habitat);
        animal.addChild(lion);

        root.add(flower);
        root.add(food);
        root.add(animal);

        String findName = "아시아";
        if (contains(root, findName)) {
            System.out.println(String.format("'%s' 디렉토리가 존재합니다.\n", findName));
        } else {
            System.out.println(String.format("'%s' 디렉토리가 존재하지 않습니다.\n", findName));
        }
        deleteDirectory(root, findName);

        System.out.println("===== 유럽 디렉토리 경로 =====");
        System.out.println(getDirectoryPath(root, "유럽"));
        System.out.println("==============================");

        System.out.println("===== 모든 디렉토리 출력 =====");
        print(root);
        System.out.println("==============================");
    }

    /**
     * 폴더 가져오기
     * @param name
     * @return
     */
    private static Directory getDirectory(List<Directory> root, String name) {
        if (root == null || root.size() == 0) {
            return null;
        }

        Directory result = null;
        for (int i = 0; i < root.size(); i++) {
            Directory directory = root.get(i);

            if (name.equals(directory.getName())) {
                result = directory;
                break;
            }

            if (!directory.hasChild()) {
                continue;
            }

            List<Directory> childList = directory.getChildList();
            for (int j = 0; j < childList.size(); j++) {
                if (result != null) {
                    break;
                }

                Directory child = childList.get(j);
                result = walkByDirectory(child, name);
            }
        }
        return result;
    }

    /**
     * 디렉토리를 삭제한다.
     * @param root
     * @param name
     */
    private static void deleteDirectory(List<Directory> root, String name) {
        Directory directory = getDirectory(root, name);
        directory.getParent().getChildList().remove(directory);
        directory.delete();
    }

    /**
     * 단일 디렉토리의 경로 가져오기
     * @param root
     * @param name
     * @return
     */
    private static String getDirectoryPath(List<Directory> root, String name) {
        Directory directory = getDirectory(root, name);

        String path = directory.getName();
        while (directory.hasParent()) {
            directory = directory.getParent();
            path = String.format("%s/%s", directory.getName(), path);
        }

        return path;
    }

    /**
     * 모든 디렉토리 출력
     * @param root
     */
    private static void print(List<Directory> root) {
        if (root == null || root.size() == 0) {
            return;
        }

        for (int i = 0; i < root.size(); i++) {
            Directory directory = root.get(i);
            System.out.println(directory.getName());

            if (directory.hasChild()) {
                walkByPrint(directory, directory.getName());
            }
        }
    }

    /**
     * 디렉토리 존재여부
     * @param root
     * @param name
     */
    private static boolean contains(List<Directory> root, String name) {
        return getDirectory(root, name) != null;
    }

    /**
     * 전체 경로 검색 용 하위 폴더 재귀 호출
     * @param directory
     * @param path
     */
    private static void walkByPrint(Directory directory, String path) {
        if (!directory.hasChild()) {
            System.out.println(path);
        }

        List<Directory> childList = directory.getChildList();
        for (int i = 0; i < childList.size(); i++) {
            Directory child = childList.get(i);
            walkByPrint(child, String.format("%s/%s", path, child.getName()));
        }
    }

    /**
     * 폴더 가져오기 용 하위 폴더 재귀 호출
     * @param directory
     * @param name
     * @return
     */
    private static Directory walkByDirectory(Directory directory, String name) {
        Directory result = null;
        List<Directory> childList = directory.getChildList();
        if (name.equals(directory.getName())) {
            return directory;
        }

        for (int i = 0; i < childList.size(); i++) {
            if (result != null) {
                break;
            }

            Directory child = childList.get(i);
            result = walkByDirectory(child, name);
        }

        return result;
    }
}
