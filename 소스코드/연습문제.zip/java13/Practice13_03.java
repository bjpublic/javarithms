package practice.java13;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 어느 중학교의 전산 시스템을 새로 구착하기 위해 학년별 출석부 프로그램이 필요합니다.
 * Map을 이용하여 필요 조건에 맞는 프로그램을 구현해 보세요.
 *
 * 조건)
 * - 학생을 입력 할 수 있어야 합니다.
 * - 학생을 출석부에서 제거 할 수 있어야 합니다.
 * - 학년, 학번, 이름으로 검색하여 화면에 출력이 가능하여야 합니다.
 */
public class Practice13_03 {
    public static void main(String[] args) {
        Map<Integer, List<Map<Integer, String>>> attendance = new HashMap<>();
        addStudent(attendance, 3, 12, "김학생");
        addStudent(attendance, 1, 20, "이학생");
        addStudent(attendance, 2, 5, "최학생");
        addStudent(attendance, 1, 12, "장학생");
        addStudent(attendance, 3, 14, "이학생");
        addStudent(attendance, 2, 9, "박학생");

        System.out.println("========= 전체 학생 출력 =========");
        printAll(attendance);
        System.out.println("");


        System.out.println("=> 2학년 중에 학생 번호 5번 출석부에서 제외");
        deleteStudent(attendance, 2, 5);

        System.out.println("========= 2학년 중에 학생 번호 5번이 제외된 전체 학생 출력 =========");
        printAll(attendance);
        System.out.println("");

        System.out.println("========= 이학생 검색 =========");
        findStudent(attendance, "이학생");
        System.out.println("");

        System.out.println("========= 학생 번호가 12인 학생들 검색=========");
        findStudent(attendance, 12);
        System.out.println("");

        System.out.println("========= 3학년 학생들 검색=========");
        findStudentsByGrade(attendance, 3);
    }

    /**
     * 출석부에 학생을 등록한다.
     * @param attendance
     * @param grade
     * @param studentId
     * @param name
     */
    private static void addStudent(Map<Integer, List<Map<Integer, String>>> attendance, int grade, int studentId, String name) {
        if (!attendance.containsKey(grade)) {
            List<Map<Integer, String>> firstGrade = new ArrayList<>();
            firstGrade.add(createStudent(studentId, name));
            attendance.put(grade, firstGrade);
            return;
        }

        List<Map<Integer, String>> students = attendance.get(grade);
        students.add(createStudent(studentId, name));
    }

    /**
     * 학생을 생성한다.
     * @param studentId
     * @param name
     * @return
     */
    private static Map<Integer, String> createStudent(int studentId, String name) {
        Map<Integer, String> student = new HashMap<>();
        student.put(studentId, name);
        return student;
    }

    /**
     * 출석부에서 학생을 제외한다.
     * @param grade
     * @param studentId
     */
    private static void deleteStudent(Map<Integer, List<Map<Integer, String>>> attendance, int grade, int studentId) {
        List<Map<Integer, String>> students = attendance.get(grade);

        Map<Integer, String> student = getStudent(attendance, grade, studentId);
        students.remove(student);
    }

    /**
     * 출석부에서 학생을 반환한다.
     * @param grade
     * @param studentId
     * @return
     */
    private static Map<Integer, String> getStudent(Map<Integer, List<Map<Integer, String>>> attendance, int grade, int studentId) {
        Map<Integer, String> result = null;

        List<Map<Integer, String>> students = attendance.get(grade);
        for (Map<Integer, String> student : students) {
            if (student.containsKey(studentId)) {
                result = student;
                break;
            }
        }
        return result;
    }

    /**
     * 학생 이름으로 찾기
     * @param attendance
     * @param name
     */
    private static void findStudent(Map<Integer, List<Map<Integer, String>>> attendance, String name) {
        Set<Integer> grades = attendance.keySet();
        for (int grade : grades) {
            List<Map<Integer, String>> students = attendance.get(grade);
            for (Map<Integer, String> student : students) {
                Set<Integer> studentIds = student.keySet();
                for (int studentId : studentIds) {
                    if (name.contains(student.get(studentId))) {
                        System.out.println(String.format("%s학년 %s번 %s", grade, studentId, student.get(studentId)));
                    }
                }
            }
        }
    }

    /**
     * 학생 번호로 찾기
     * @param attendance
     * @param studentId
     */
    private static void findStudent(Map<Integer, List<Map<Integer, String>>> attendance, int studentId) {
        Set<Integer> grades = attendance.keySet();
        for (int grade : grades) {
            List<Map<Integer, String>> students = attendance.get(grade);
            for (Map<Integer, String> student : students) {
                if (student.containsKey(studentId)) {
                    System.out.println(String.format("%s학년 %s번 %s", grade, studentId, student.get(studentId)));
                    break;
                }
            }
        }
    }

    /**
     * 학년 별 학생 찾기
     * @param attendance
     * @param grade
     */
    private static void findStudentsByGrade(Map<Integer, List<Map<Integer, String>>> attendance, int grade) {
        List<Map<Integer, String>> students = attendance.get(grade);
        for (Map<Integer, String> student : students) {
            Set<Integer> studentIds = student.keySet();
            for (int studentId : studentIds) {
                System.out.println(String.format("%s학년 %s번 %s", grade, studentId, student.get(studentId)));
            }
        }
    }

    /**
     * 출석부 모든 학생 출력
     */
    private static void printAll(Map<Integer, List<Map<Integer, String>>> attendance) {
        Set<Integer> keys = attendance.keySet();
        for (int grade : keys) {
            List<Map<Integer, String>> students = attendance.get(grade);
            for (Map<Integer, String> student : students) {
                Set<Integer> studentIds = student.keySet();
                for (int studentId : studentIds) {
                    System.out.println(String.format("%s학년 %s번 %s", grade, studentId, student.get(studentId)));
                }
            }
        }
    }
}
