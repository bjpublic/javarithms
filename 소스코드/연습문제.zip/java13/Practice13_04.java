package practice.java13;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

/**
 * HashSet을 이용하여 정수 1~45 중 임의의 값 6개를 받은 뒤, 당첨 번호와 비교하여 일치하는
 * 개수만큼 금액을 가지는 복권의 한 종류인 로또 프로그램을 구현해 보세요.
 *
 * 조건)
 * 당첨 번호: 15, 27, 13, 12, 41, 43
 * 1등 일치하는 번호 개수: 6, 금액: 100,000,000원
 * 2등 일치하는 번호 개수: 5, 금액: 50,000,000원
 * 3등 일치하는 번호 개수: 4, 금액: 1,000,000원
 * 4등 일치하는 번호 개수: 3, 금액: 50,000원
 * 5등 일치하는 번호 개수: 2, 금액: 5,000원
 */
public class Practice13_04 {
    public static void main(String[] args) {
        Random random = new Random();
        Set numbers = new HashSet<Integer>(){{
            add(15);
            add(27);
            add(13);
            add(12);
            add(41);
            add(43);
        }};

        Set<Integer> myNumbers = new HashSet<>();
        while (myNumbers.size() < numbers.size()) {
            int number = random.nextInt(45);
            if (number == 0) {
                continue;
            }

            myNumbers.add(number);
        }

        int count = 0;

        Iterator iterator = myNumbers.iterator();
        while (iterator.hasNext()) {
            if (!numbers.contains(iterator.next())) {
                continue;
            }
            count++;
        }

        switch (count) {
            case 2:
                System.out.println("축하합니다. 5등에 당첨 되었습니다.");
                System.out.println("수령 금액: 5,000");
                break;
            case 3:
                System.out.println("축하합니다. 4등에 당첨 되었습니다.");
                System.out.println("수령 금액: 50,000");
                break;
            case 4:
                System.out.println("축하합니다. 3등에 당첨 되었습니다.");
                System.out.println("수령 금액: 1,000,000");
                break;
            case 5:
                System.out.println("축하합니다. 2등에 당첨 되었습니다.");
                System.out.println("수령 금액: 50,000,000");
                break;
            case 6:
                System.out.println("축하합니다. 1등에 당첨 되었습니다.");
                System.out.println("수령 금액: 100,000,000");
                break;
            default:
                System.out.println("당첨되지 않았습니다.");
        }
    }
}
