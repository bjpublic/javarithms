package practice.java11;

import java.util.Arrays;

/**
 * [1, 12, 15, 7, 3, 9, 10, 8, 2, 5, 4]의 데이터를 담고 있는 배열이 있습니다.
 * 이 배열을 내림차순으로 병합 정렬하고 분할-병합 과정을 모두 출력해 보세요.
 */
public class Practice11_01 {
    public static void main(String[] args) {
        int[] arr = {1, 12, 15, 7, 3, 9, 10, 8, 2, 5, 4};
        merge(arr, 0, arr.length - 1);
    }

    private static void mergeSort(int arr[], int start, int div, int end) {
        int[] temp = new int[arr.length];

        int s = start;
        int r = div + 1;
        int k = start;


        int[] targetArr1 = new int[arr.length];
        for (int i = 0, s1 = s; s1 <= div; s1++) {
            targetArr1[i] = arr[s1];
        }

        int[] targetArr2 = new int[arr.length];
        for (int j = 0, r1 = r; r1 <= end; r1++) {
            targetArr2[j] = arr[r1];
        }
        System.out.println(String.format("[병합 과정] %s , %s",
                Arrays.toString(targetArr1), Arrays.toString(targetArr2)));

        while (s <= div && r <= end) {
            if (arr[s] >= arr[r]) {
                temp[k++] = arr[s++];
            } else {
                temp[k++] = arr[r++];
            }
        }

        while (s <= div) {
            temp[k++] = arr[s++];
        }

        while (r <= end) {
            temp[k++] = arr[r++];
        }
        System.out.println(String.format("[병합 결과] %s ",Arrays.toString(temp)));
        System.out.println("=================================================================================");

        for (int h = 0; h <= end - start; h++) {
            arr[start + h] = temp[start + h];
        }
    }

    private static void merge(int arr[], int left, int right) {
        if (left < right) {
            int div = (left + right) / 2;

            System.out.print("[분할 과정] ");
            for (int i = left; i < div; i++) {
                System.out.print(arr[i] + " ");
            }
            System.out.println("");
            merge(arr, left, div);

            System.out.print("[분할 과정] ");
            for (int i = div + 1; i <= right; i++) {
                System.out.print(arr[i] + " ");
            }
            System.out.println("");
            merge(arr, div + 1, right);

            mergeSort(arr, left, div, right);
        }
    }
}
