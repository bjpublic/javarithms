package practice.java01;

/**
 * 중복을 포함한 다섯 개의 값 중에서 최댓값을 구하는 메서드를 작성해 보세요.
 */
public class Practice01_2 {
    public static void main(String[] args) {
        int min = maxValue(20, 31, 15, 31, 7);
        System.out.println("최댓값: " + min);
    }

    private static int maxValue(int data1, int data2, int data3, int data4, int data5) {
        int max = data1;
        if (data2 > max) {
            max = data2;
        }

        if (data3 > max) {
            max = data3;
        }

        if (data4 > max) {
            max = data4;
        }

        if (data5 > max) {
            max = data5;
        }

        return max;
    }
}
