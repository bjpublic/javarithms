package practice.java01;

/**
 * 네 개의 값에서 최솟값을 구하는 메서드를 작성해 보세요.
 */
public class Practice01_1 {
    public static void main(String[] args) {
        int min = minValue(5, 9, 2, 13);
        System.out.println("최솟값: " + min);
    }

    private static int minValue(int data1, int data2, int data3, int data4) {
        int min = data1;
        if (data2 < min) {
            min = data2;
        }

        if (data3 < min) {
            min = data3;
        }

        if (data4 < min) {
            min = data4;
        }

        return min;
    }
}
