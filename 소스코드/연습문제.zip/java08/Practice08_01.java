package practice.java08;

import java.util.Arrays;

/**
 * "HelloWorld” 문자열을 선택정렬을 사용하여 오름차순으로 정렬해 보세요.
 */
public class Practice08_01 {
    public static void main(String[] args) {
        String str = "HelloWorld";
        String[] arr = str.split("");

        for (int i = 0; i < arr.length - 1; i++) {
            int minIndex = i;
            for (int j = i; j < arr.length; j++) {
                if (arr[minIndex].hashCode() < arr[j].hashCode()) {
                    continue;
                }

                minIndex = j;
            }

            String temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }

        System.out.println("결과: " + Arrays.toString(arr));
    }
}
