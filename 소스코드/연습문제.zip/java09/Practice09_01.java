package practice.java09;

import java.util.Arrays;

/**
 * “llll looo lloo oolo loll oool" 2진수를 나타내는 문자열이 존재합니다.
 *  위 문자열을 10진수로 변환하여 배열에 차례대로 넣은 뒤,
 *  삽입정렬을 이용하여 오름차순으로 정렬해 보세요. (삽입정렬의 반복문은 while문을 사용하세요.)
 *  예) "oool looo ooll oolo" => [1, 8, 3, 2] => [1, 2, 3, 8]
 */
public class Practice09_01 {
    public static void main(String[] args) {
        String str = "llll looo lloo oolo loll oool";

        String[] temp = str.split(" ");
        int[] arr = new int[temp.length];

        for (int i = 0; i < temp.length; i++) {
            String binary = temp[i];

            String[] binaryArr = binary.split("");
            int sum = 0;
            for (int j = binaryArr.length - 1; j >= 0; j--) {
                if ("o".equals(binaryArr[j])) {
                    continue;
                }

                int cnt = 3 - j;
                int num = 1;
                while ((cnt--) > 0) {
                    num = num * 2;
                }
                sum += num;
            }

            arr[i] = sum;
        }

        sort(arr);
        System.out.println("결과: " + Arrays.toString(arr));
    }

    private static void sort(int[] arr) {
        int i = 1;
        while (i < arr.length) {
            int target = arr[i];

            int j = i - 1;
            while (j >= 0 && arr[j] > target) {
                arr[j + 1] = arr[j];
                j--;
            }

            arr[j + 1] = target;
            i++;
        }
    }
}
