package practice.java07;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 * 입력 받은 값의 크기만큼 배열을 생성하고, 각 요소는 중복되지 않으며,
 * 무작위 값으로 초기화하여 내림차순으로 정렬해 보세요. (1 < n <= 입력받은 값) (n은 자연수)
 * 예제)  입력 값: 5  생성된 배열: [5, 2, 3, 1, 4]  결과 값: [5, 4, 3, 2, 1]
 */
public class Practice07_01 {
    public static void main(String[] args) {
        System.out.println("배열의 크기를 입력해주세요.");
        Scanner scanner = new Scanner(System.in);
        int length = scanner.nextInt();

        Random random = new Random();
        int[] arr = new int[length];

        int index = 0;
        while (index < length) {
            int randomValue = random.nextInt(length + 1);

            boolean contains = false;
            for (int j = 0; j < arr.length; j++) {
                if (arr[j] == randomValue) {
                    contains = true;
                    break;
                }
            }

            if (!contains) {
                arr[index++] = randomValue;
            }
        }

        for (int i = 1; i < arr.length; i++) {
            for (int j = 0; j < arr.length - i; j++) {
                if (arr[j] < arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

        System.out.println("결과: " +  Arrays.toString(arr));
    }
}
