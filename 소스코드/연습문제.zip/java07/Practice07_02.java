package practice.java07;

/**
 * 100,000 크기를 가진 배열이 오름차순으로 정렬되어 있습니다.
 * 이미 정렬을 마친 배열에 대해서 다시 거품정렬을 시도하려 합니다.
 * 정렬된 배열인 경우 거품정렬을 하지 않도록 거품정렬 알고리즘을 구현해 보세요.
 */
public class Practice07_02 {
    public static void main(String[] args) {
        int[] arr = new int[100000];
        for (int i = 0; i < 100000; i++) {
            arr[i] = i;
        }

        boolean isSorted = false;
        for (int i = 1; i < arr.length; i++) {
            for (int j = 0; j < arr.length - i; j++) {
                isSorted = true;
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    isSorted = false;
                }
            }

            if (isSorted) {
                break;
            }
        }
    }
}
