package practice.java06;

import heapTree.MaxHeapTree;

/**
 * 최대 힙 트리를 아래 메서드와 함께 구현해 보세요.
 * 삽입 메서드
 * 삭제 메서드
 */
public class Practice06_2_1 {
    public static void main(String[] args) {
        MaxHeapTree maxHeapTree = new MaxHeapTree(7);
        maxHeapTree.insert(10);
        maxHeapTree.insert(5);
        maxHeapTree.insert(12);
        maxHeapTree.insert(20);
        maxHeapTree.insert(1);
        maxHeapTree.insert(100);
        maxHeapTree.insert(21);

        maxHeapTree.delete();
        maxHeapTree.print();
    }
}
