package practice.java05;

/**
 * LinkedListDeque 클래스의 removeFirst(), removeLast() 메서드에서
 * 데이터가 존재하지 않을 때의 예외처리를 코드로 작성해 보세요.
 */
public class Practice05_4_2 {
    /**
    public Object removeFirst() {
        if (front == null) {
            System.out.println("[ERROR] 앞 요소가 존재하지 않습니다. (size 0)");
            return null;
        }

        Object value = front.getValue();
        front = front.next;

        return value;
    }

    public Object removeLast() {
        if (rear == null) {
            System.out.println("[ERROR] 뒤 요소가 존재하지 않습니다. (size 0)");
            return null;
        }

        Object value = rear.getValue();

        Node temp = front;
        while (temp != null) {
            if (temp.next != rear) {
                temp = temp.next;
                continue;
            }

            rear = temp;
            rear.next = null;
        }

        if (front == rear) {
            front = null;
            rear = null;
        }

        return value;
    }
    **/
}
