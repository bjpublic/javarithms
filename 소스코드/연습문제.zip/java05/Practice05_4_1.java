package practice.java05;

/**
 * LinkedListDeque 클래스의 print() 메서드에서
 * while문을 for문으로 수정하여 같은 결과를 출력해 보세요.
 */
public class Practice05_4_1 {
    /**
    public String printByForLoop() {
        if (front == null) {
            return "deque is empty";
        }
        String datas = "";
        Node temp = front;

        for (; temp.next != null; temp = temp.next) {
            datas += String.format("%s->", temp.getValue());
        }

        datas += String.format("%s", temp.getValue());
        return datas;
    }
    **/
}
