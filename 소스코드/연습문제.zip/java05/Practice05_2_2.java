package practice.java05;

import queue.linkedlist.LinkedListQueue;

import java.util.Scanner;

/**
 * 큐를 이용하여 간단한 은행 창구표 시스템을 구현해 보세요. 조건은 다음과 같습니다.
 *  대기 번호 표는 1부터 시작합니다.
 *  먼저 뽑은 사람이 먼저 은행 업무를 볼 수 있습니다.
 *  대기 번호 표는 재사용하지 않습니다.
 *  대기 인원을 확인 할 수 있습니다.
 */
public class Practice05_2_2 {
    public static void main(String[] args) {
        LinkedListQueue queue = new LinkedListQueue();

        int count = 1;
        int size = 0;
        boolean isStop = false;

        while (!isStop) {
            System.out.println("1.    대기표 발급받기");
            System.out.println("2.    입장하기");
            System.out.println("3.    총인원 확인하기");
            System.out.println("4.    종료하기");
            System.out.print("=>");

            int choose = new Scanner(System.in).nextInt();
            switch (choose) {
                case 1:
                    queue.enqueue(count);
                    System.out.println(String.format("대기 번호: %s번 발급되었습니다.\n", count));

                    count++;
                    size++;
                    break;
                case 2:
                    if (queue.empty()) {
                        System.out.println("대기 중인 고객이 없습니다.\n");
                        break;
                    }

                    int number = (int) queue.dequeue();
                    System.out.println(String.format("%s번 은행 창구로 이동해 주세요.\n", number));
                    size--;
                    break;
                case 3:
                    System.out.println(String.format("현재 인원은 %s명 입니다.\n", size));
                case 4:
                    System.out.println("종료합니다.\n");
                    isStop = true;
                    break;
                default:
                        System.out.println("1.    대기표 발급");
                        System.out.println("2.    입장하기");
                        System.out.println("3.    총인원 확인");
                        System.out.print("=>");
            }
        }
    }
}
