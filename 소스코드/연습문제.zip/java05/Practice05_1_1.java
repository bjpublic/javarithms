package practice.java05;

/**
 * 지금까지 배운 스택 클래스에서 아래 메서드를 구현해 보세요.
 * contains(Object value): value 값이 포함되어 있으면 true, 포함되어 있지 않으면 false를 반환합니다.
 * size(): 스택의 크기를 반환합니다.
 */
public class Practice05_1_1 {
    /**
    public boolean contains(Object value) {
        boolean result = false;
        for (Object data : stack) {
            if (data instanceof String && data.equals(value)
                    || data == value) {
                result = true;
                break;
            }
        }
        return result;
    }

    public int size() {
        return stack.length;
    }
    **/
}
