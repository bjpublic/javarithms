package practice.java05;

/**
 * 정수를 담고 있는 배열 또는 연결리스트로 구현된 큐의
 * 모든 요소를 출력하는 printAll() 메서드를 구현해 보세요.
 */
public class Practice05_2_1 {
    /**
    public void printAll() {
        Node temp = front;
        while (temp.next != null) {
            System.out.println(temp.getValue());
            temp = temp.next;
        }
    }
    **/
}
