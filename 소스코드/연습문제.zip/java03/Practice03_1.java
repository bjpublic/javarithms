package practice.java03;

/**
 * 챕터 3.4의 단일 연결 리스트 삽입 메서드에서 중복을 허용하지 않는 삽입 메서드로 수정해 보세요.
 */
public class Practice03_1 {
    /*
    public void append(int value) {
        if (this.head == null) {
            this.head = new Node(value, null);
            return;
        }

        Node pointer = this.head;
        while (pointer.next != null) {
            if (pointer.getValue() == value) {
                System.out.println(String.format("중복 데이터가 존재하여 %s을(를) 삽입 할 수 없습니다.", value));
                return;
            }
            pointer = pointer.next;
        }

        if (pointer.getValue() == value) {
            System.out.println(String.format("중복 데이터가 존재하여 %s을(를) 삽입 할 수 없습니다.", value));
            return;
        }

        pointer.next = new Node(value, null);
    }
    */
}
