package practice.java12;

import java.util.Arrays;
import java.util.Random;

/**
 * 불안전한 정렬인 퀵정렬은 이미 정렬이 되어 있는 배열이거나 잘못된 피벗을 선택하는 경우에는
 * 최악의 시간복잡도 n^2이란 시간이 걸립니다.
 * 퀵 정렬을 개선하기 위한 방법으로 첫번째와 중간, 마지막 요소를 정렬하여 중간 값으로
 * 피벗을 선정하는 방법과 확률에 의존적인 임의의 피벗을 선정하는 방법, 분할 - 정복 과정에서
 * 크기가 작을 경우 비교적 구현이 간단한 삽입 정렬 알고리즘을 이용하는 방법과 같은
 * * 각각의 개선 방법으로 퀵정렬 알고리즘을 수정해 보세요.
 *
 */
public class Practice12_01 {
    // 첫번째, 중간, 마지막 요소를 정렬하여 피벗을 선정하는 방법
    public static void main(String[] args) {
        int[] arr = new int[]{60,59,58,57,56,55,54,53,52,51,50,
                49,48,47,46,45,44,43,42,41,40,
                39,38,37,36,35,34,33,32,31,30,
                29,28,27,26,25,24,23,22,21,20,
                19,18,17,16,15,14,13,12,11,10,
                9,8,7,6,5,4,3,2,1
        };

        quick(arr, 0, arr.length - 1);
        System.out.println(Arrays.toString(arr));
    }

    private static void sortByPivot(int[] arr) {
        int middle = arr.length / 2;

        for (int i = 0; i < arr.length; i += middle) {
            for (int j = i; j < arr.length; j += middle) {
                if (arr[i] > arr[j]) {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
    }

    private static int getPivotByRandom(int[] arr) {
        Random random = new Random();
        return arr[random.nextInt(arr.length)];
    }

    private static void insertionSort(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            int target = arr[i];

            int j;
            for (j = i - 1; j >= 0 && arr[j] > target; j--) {
                arr[j + 1] = arr[j];
            }

            arr[j + 1] = target;
        }
    }

    private static void quick(int[] arr, int start, int end) {
        // 정렬 할 배열의 크기가 50이하 일 경우에 삽입 정렬 사용
        if (arr.length <= 50) {
            insertionSort(arr);
            return;
        }

        if (start >= end) {
            return;
        }

        int left = start;
        int right = end;

//        첫번째와 중간, 마지막 요소를 정렬하여 중간 값으로 pivot을 선정
//        sortByPivot(arr);
//        int pivot = arr[(start + end) / 2];

        int pivot = getPivotByRandom(arr); // 임의의 피벗을 선정하는 방법,


        while (left < right) {
            while (arr[left] < pivot) {
                left++;
            }

            while (arr[right] > pivot) {
                right--;
            }

            if (left >= right) {
                break;
            }

            if (arr[left] == pivot && arr[right] == pivot) {
                left++;
                continue;
            }

            int temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;
        }

        quick(arr, start, left - 1);
        quick(arr, left + 1, end);
    }
}
